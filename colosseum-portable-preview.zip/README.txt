Colosseum Berlin — portable preview
===================================

Double-click index.html. That's it — no install, no server, no internet
connection required for the app itself.

Works in Chrome, Edge, Firefox and Safari straight off the filesystem, and
runs the same from a USB stick, a shared drive or an email attachment.

What needs internet (everything degrades gracefully without it):
  - event poster artwork  -> falls back to local venue photos
  - the 360 virtual tour  -> shows a "launch in new tab" card
  - Google Fonts          -> falls back to system fonts

Demo credentials
  staff check-in PIN  1895
  promo codes         COLOSSEUM10 (10%)  BERLIN25 (25%)  STAFF (50%)

Everything is mock data held in your browser's local storage. Profile >
Reset demo clears it.
